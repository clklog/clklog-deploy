window.globalConfig = {
  BASE_API: "/api", //clklog-api接口基础路径
  BASE_API_MANAGE: "/manage", //clklog-manage-api接口基础路径
  BASE_API_AUTHMANAGE:"/authmanage",//clklog-manage-api接口基础路径
  copyRight: "ClkLog", //配置系统名称
  appPath: "/", //虚拟目录用于相对或绝对路径下"配置logo等图片"引用地址
  copyRightUrl: "https://clklog.com/#/introduce" //系统外链官网
};
