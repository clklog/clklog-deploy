window.globalConfig = {
  BASE_API: "/api", //clklog-api接口基础路径
  BASE_API_MANAGE: "/manage" //clklog-manage-api接口基础路径
};
